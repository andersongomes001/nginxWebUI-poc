package com.cym.model;

public class Version {
	String version;
	String docker;
	String url;
	String update;
	
	
	
	public String getUpdate() {
		return update;
	}

	public void setUpdate(String update) {
		this.update = update;
	}

	public String getDocker() {
		return docker;
	}

	public void setDocker(String docker) {
		this.docker = docker;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
